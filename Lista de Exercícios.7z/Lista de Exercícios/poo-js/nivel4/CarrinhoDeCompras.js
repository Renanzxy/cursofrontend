// Exemplo de código para CarrinhoDeCompras.js
