// Exemplo de código para Biblioteca.js
