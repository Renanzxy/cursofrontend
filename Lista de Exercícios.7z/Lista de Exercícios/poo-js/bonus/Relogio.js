// Exemplo de código para Relogio.js
