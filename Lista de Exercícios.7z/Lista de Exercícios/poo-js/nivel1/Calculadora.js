// Exemplo de código para Calculadora.js
