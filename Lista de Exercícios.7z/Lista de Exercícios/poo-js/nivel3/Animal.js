// Exemplo de código para Animal.js
