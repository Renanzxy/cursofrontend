// Exemplo de código para Gato.js
