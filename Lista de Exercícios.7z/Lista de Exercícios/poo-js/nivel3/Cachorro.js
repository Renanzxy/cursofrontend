// Exemplo de código para Cachorro.js
