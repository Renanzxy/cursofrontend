// Exemplo de código para Funcionario.js
