// Exemplo de código para Carro.js
