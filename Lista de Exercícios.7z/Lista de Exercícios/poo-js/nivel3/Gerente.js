// Exemplo de código para Gerente.js
