
// Exercício 1: Criando e manipulando arrays
let frutas = ["maçã", "banana", "laranja", "uva"];
console.log(frutas[1]);  // Segundo elemento
frutas.push("melancia"); // Adicionando no final
frutas.shift(); // Removendo o primeiro elemento
console.log(frutas.length); // Comprimento do array
