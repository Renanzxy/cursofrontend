
// Exercício 5: Procurando elementos
let elementos = ["carro", "moto", "bicicleta", "avião", "barco"];
console.log(elementos.includes("moto")); // Verificando se "moto" está no array
console.log(elementos.indexOf("avião")); // Encontrando posição de "avião"
