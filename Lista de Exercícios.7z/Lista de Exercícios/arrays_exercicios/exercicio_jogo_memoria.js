
// Exercício Jogo da Memória
let palavras = ["gato", "gato", "cão", "cão"];
palavras = palavras.sort(() => Math.random() - 0.5);  // Embaralha as palavras
console.log(palavras);
