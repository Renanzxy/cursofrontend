
// Exercício 2: Iterando sobre arrays
let numeros = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
// Usando um loop for
for (let i = 0; i < numeros.length; i++) {
    console.log(numeros[i]);
}
// Usando forEach
numeros.forEach(num => console.log(num));
